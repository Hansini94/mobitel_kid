<div class="clearfix"></div>

      <div class="container">

        <div class="row m-auto">

            <div class="col-xxl-6 offset-xxl-3 col-xl-6 offset-xl-3 col-lg-6 offset-lg-3 col-md-12 col-sm-12 col-12">

              <!-- kid image -->
              <img src="<?php echo base_url("assets/frontend/images/kid04.png"); ?>" alt="" class="kid_04 d-none d-sm-none d-md-block" data-aos="fade-down">
              <!-- kid image -->

              <!-- kid image -->
              <div class="position-relative d-none d-sm-none d-md-block">
                <div class="position-absolute top-0 end-0">
                   <img src="<?php echo base_url("assets/frontend/images/kid03.png"); ?>" alt="" class="start-end kid_03" data-aos="fade-up">
                </div>
              </div>
              <!-- kid image -->

              <div class="form_blue_box shadow rounded">

                <!-- language button -->
                <div class="lang_div">
                  <div class="position-relative">
                    <div class="position-absolute top-0 end-0">
                      <a href="<?php echo base_url('Terms-of-use-Si');?>"><button class="btn btn-primary blue_white_btn">සිං</button></a>
                      <a href="<?php echo base_url('Terms-of-use-Ta');?>"><button class="btn btn-primary blue_white_btn">தமி</button></a>
                    </div>
                  </div>
                </div>
                <!-- language button -->
                
                <div class="row m-auto">
                  
                  <div class="shadow p-3 bg-body rounded mb-3" style="width: max-content;">
                    <a href="<?php echo base_url("Home-En");?>">
                      <img src="<?php echo base_url("assets/frontend/images/logo.png"); ?>" alt="" class="top_logo aos-init aos-animate" data-aos="fade-down">
                    </a>
                  </div>

                  <h1 class="heading" style="color: #ffffff; padding-left: 0px;" data-aos="fade-down">Terms and Conditions</h1>
                  <p style="padding-left: 0px;" data-aos="fade-down">
                   <?php echo $terms->tContent_eng; ?>
                  </p>

                  <!-- <p style="padding-left: 0px;" data-aos="fade-down">
                   Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                  </p>

                  <p style="padding-left: 0px;" data-aos="fade-down">
                   Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                  </p> -->

                </div>

                <div class="clearfix"></div> 

              </div>

               <!-- kid image -->
              <div class="position-relative d-none d-sm-none d-md-none d-lg-block">
                <div class="position-absolute bottom-0 start-0">
                   <img src="<?php echo base_url("assets/frontend/images/kid01.png"); ?>" alt="" class="start-end kid_01" data-aos="fade-up">
                </div>
              </div>
              <!-- kid image -->

               <!-- kid image -->
              <div class="position-relative">
                <div class="position-absolute bottom-0 end-0">
                   <img src="<?php echo base_url("assets/frontend/images/kid02.png"); ?>" alt="" class="start-end kid_02" data-aos="fade-up">
                </div>
              </div>
              <!-- kid image -->

            </div>

          </div>

      </div>

      <!-- ======================= -->